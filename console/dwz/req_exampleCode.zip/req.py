import requests
import hashlib
import json

url = "https://xxx/console/dwz/create/"

# 设置请求参数
dwz_title = "API生成"
dwz_dlws = 4
dwz_type = 1
dwz_url = "https://www.qq.com"
api_key = "xxx"
api_secret = "xxxxxxxxxxxxxxxxx"

# 创建包含请求参数的字典
payload = {
    "dwz_title": dwz_title,
    "dwz_dlws": dwz_dlws,
    "dwz_type": dwz_type,
    "dwz_url": dwz_url,
    "api_key": api_key,
}

# 拼接参数以进行 MD5 加密
data_to_sign = f"{dwz_title}{dwz_type}{dwz_url}{api_key}{api_secret}"
hashed_data = hashlib.md5(data_to_sign.encode()).hexdigest()

# 将签名参数添加到 payload 中
payload["sign"] = hashed_data

# 将 payload 转换为 JSON
json_payload = json.dumps(payload)

# 设置请求头，指定内容类型为 JSON
headers = {"Content-type": "application/json"}

# 发送 POST 请求
response = requests.post(url, data=json_payload, headers=headers)

# 打印响应内容
print(response.text)
